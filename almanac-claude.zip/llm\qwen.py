"""Qwen3-0.6B via Hugging Face transformers. Runs on this machine; nothing is sent to a hosted API."""
from __future__ import annotations

import os
import threading

MODEL_ID = os.environ.get("QWEN_MODEL", "Qwen/Qwen3-0.6B")


class QwenChat:
    def __init__(self, model_id: str = MODEL_ID, device: str | None = None):
        import torch  # imported here so the guards and tests work without torch installed
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.model_id = model_id
        self.device = device or ("cuda" if torch.cuda.is_available() else "mps" if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available() else "cpu")
        self.tok = AutoTokenizer.from_pretrained(model_id)
        # bf16 on CUDA; fp32 on CPU and Apple GPUs, which is the safe choice (0.6B is only ~2.4 GB in fp32)
        dtype = torch.bfloat16 if self.device == "cuda" else torch.float32
        try:
            self.model = AutoModelForCausalLM.from_pretrained(model_id, dtype=dtype)
        except TypeError:  # transformers < 4.56 spells it torch_dtype
            self.model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=dtype)
        self.model.to(self.device).eval()
        self._torch = torch
        self._lock = threading.Lock()  # one generation at a time

    def generate(self, messages: list[dict], max_new_tokens: int = 200, temperature: float = 0.0) -> str:
        # Qwen3 "thinking" is off: it is slow and a 0.6B model's reasoning adds nothing here.
        prompt = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
        inputs = self.tok([prompt], return_tensors="pt").to(self.device)
        # Qwen's recommended non-thinking settings: temperature 0.7, top_p 0.8, top_k 20. Lower temperature keeps it on the facts.
        sample = {"do_sample": True, "temperature": temperature, "top_p": 0.8, "top_k": 20} if temperature > 0 else {"do_sample": False}
        with self._lock, self._torch.inference_mode():
            out = self.model.generate(**inputs, max_new_tokens=max_new_tokens, pad_token_id=self.tok.eos_token_id, **sample)
        return self.tok.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True).strip()

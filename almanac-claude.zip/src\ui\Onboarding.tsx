import { useEffect, useRef, useState } from 'react'
import { useApp } from '../state'
import { money } from '../lib/format'
import { animate, createTimeline, reducedMotion } from '../lib/motion'

type Step = 'welcome' | 'consent' | 'reading'

export function Onboarding() {
  const app = useApp()
  const [step, setStep] = useState<Step>('welcome')
  const [agree, setAgree] = useState(false)
  const box = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (box.current && !reducedMotion()) animate(box.current, { opacity: [0, 1], translateY: [14, 0], duration: 520, ease: 'outQuint' })
  }, [step])

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-[#160A2B] p-8">
      <div className="pointer-events-none absolute inset-0 opacity-60" style={{ background: 'radial-gradient(900px 500px at 70% 20%, rgba(94,224,181,.12), transparent 60%), radial-gradient(800px 600px at 20% 90%, rgba(124,92,196,.25), transparent 60%)' }} />
      <div ref={box} className="relative w-full max-w-[620px]">
        {step === 'welcome' && <Welcome onNext={() => setStep('consent')} onSkip={app.finishOnboarding} />}
        {step === 'consent' && (
          <div className="rounded-2xl bg-white p-8 text-ink shadow-2xl">
            <p className="text-[13px] font-medium text-brand">Connect with Open Banking</p>
            <h2 className="mt-1 text-[24px] font-semibold tracking-tight">Almanac would like to read your current account</h2>
            <div className="mt-5 grid grid-cols-3 gap-4 text-[13px]">
              <div className="rounded-xl bg-bg p-4">
                <p className="font-semibold">What it will see</p>
                <p className="mt-1 text-sub">Your balance and the last 90 days of transactions.</p>
              </div>
              <div className="rounded-xl bg-bg p-4">
                <p className="font-semibold">What it can’t do</p>
                <p className="mt-1 text-sub">Move money, make payments, or see your login details.</p>
              </div>
              <div className="rounded-xl bg-bg p-4">
                <p className="font-semibold">How long</p>
                <p className="mt-1 text-sub">90 days. You can disconnect at any time.</p>
              </div>
            </div>
            <label className="mt-5 flex items-start gap-3 text-[14px]">
              <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#4b2a86]" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              <span>I agree to Almanac reading my account to give me guidance. My data won’t be sold or used for anything else.</span>
            </label>
            <div className="mt-6 flex items-center justify-between">
              <button onClick={() => setStep('welcome')} className="text-[14px] text-sub hover:text-ink">Back</button>
              <button disabled={!agree} onClick={() => setStep('reading')}
                className="h-11 rounded-xl bg-ink px-5 text-[14px] font-semibold text-white disabled:opacity-30">Connect demo account</button>
            </div>
            <p className="mt-4 text-[12px] text-mute">Demo uses synthetic data in the UK Open Banking format. In production, access runs through an FCA-authorised account information service.</p>
          </div>
        )}
        {step === 'reading' && <Reading onDone={app.finishOnboarding} />}
      </div>
    </div>
  )
}

function Welcome({ onNext, onSkip }: { onNext: () => void; onSkip: () => void }) {
  return (
    <div className="text-white">
      <p className="text-[15px] font-semibold tracking-tight text-[#5EE0B5]">Almanac</p>
      <h1 className="mt-4 text-[52px] font-semibold leading-[1.02] tracking-[-0.03em]">The wealth manager for everyone else.</h1>
      <p className="mt-6 max-w-[52ch] text-[17px] leading-relaxed text-[#D9D1EA]">
        Wealthy people have someone who checks every bill, plans for bad months and makes every pound work. Most people never get that. Almanac does it for you, from your own bank transactions, in plain English.
      </p>
      <div className="mt-8 grid grid-cols-3 gap-4 border-y border-white/10 py-5">
        {[
          ['12.9m', 'UK adults with low financial resilience: one bad month from trouble', 'FCA Financial Lives'],
          ['£24bn', 'of benefits and social tariffs go unclaimed every year', 'Policy in Practice, 2025/26'],
          ['1 in 12', 'households on Universal Credit use the cheap broadband they’re entitled to', 'Ofcom, 2026'],
        ].map(([n, t, src]) => (
          <div key={n}>
            <p className="text-[28px] font-semibold tracking-tight text-[#5EE0B5]">{n}</p>
            <p className="mt-1 text-[13px] leading-snug text-[#D9D1EA]">{t}</p>
            <p className="mt-1 text-[11px] text-[#8C7DAD]">{src}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 flex items-center gap-5">
        <button onClick={onNext} className="h-12 rounded-xl bg-white px-6 text-[15px] font-semibold text-[#24123F] hover:bg-[#EDE8F6]">Connect your bank</button>
        <button onClick={onSkip} className="text-[14px] text-[#B9AED3] hover:text-white">Skip to the demo</button>
      </div>
    </div>
  )
}

function Reading({ onDone }: { onDone: () => void }) {
  const { persona, learned, actions, progs, baseline, score } = useApp()
  const list = useRef<HTMLUListElement>(null)
  const bar = useRef<HTMLDivElement>(null)
  const [ready, setReady] = useState(false)
  const found = actions.filter((a) => a.counts).reduce((s, a) => s + a.yearly, 0)
  const irregular = persona.history.filter((t) => /NHSP/.test(t.merchant)).length
  const worst = baseline.days.reduce((w, d) => (d.pNeg > w.pNeg ? d : w))
  const lines = [
    `Read ${persona.history.length} transactions from the last 90 days`,
    `Found ${learned.recurring.length} regular payments, from rent to Spotify`,
    `Spotted irregular income: ${irregular} bank shifts, mostly on Fridays`,
    `Simulated your next 90 days 400 times`,
    `Christmas week: up to ${Math.round(worst.pNeg * 100)}% chance of going overdrawn`,
    `Found ${money(found)} a year you could keep`,
    `Valued ${progs.length} points balances: worth up to ${money(progs.reduce((a, p) => a + p.best, 0))}`,
    `Your resilience score: ${score} out of 100`,
  ]
  useEffect(() => {
    if (!list.current) return
    const items = list.current.querySelectorAll('li')
    if (reducedMotion()) { items.forEach((i) => ((i as HTMLElement).style.opacity = '1')); setReady(true); return }
    const tl = createTimeline({ onComplete: () => setReady(true) })
    items.forEach((li, i) => {
      tl.add(li, { opacity: [0, 1], translateX: [-10, 0], duration: 380, ease: 'outQuint' }, i === 0 ? 200 : '+=330')
    })
    if (bar.current) animate(bar.current, { width: ['0%', '100%'], duration: lines.length * 700, ease: 'inOutQuad' })
    return () => { tl.pause() }
  }, []) // eslint-disable-line
  return (
    <div className="rounded-2xl bg-white p-8 text-ink shadow-2xl">
      <p className="text-[13px] font-medium text-brand">Connected</p>
      <h2 className="mt-1 text-[24px] font-semibold tracking-tight">Getting to know your money</h2>
      <div className="mt-4 h-1 overflow-hidden rounded-full bg-line-2"><div ref={bar} className="h-full bg-brand" style={{ width: reducedMotion() ? '100%' : '0%' }} /></div>
      <ul ref={list} className="mt-5 space-y-2.5">
        {lines.map((l) => (
          <li key={l} className="flex items-center gap-3 text-[15px]" style={{ opacity: 0 }}>
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gain-soft text-[11px] font-bold text-gain">✓</span>{l}
          </li>
        ))}
      </ul>
      <div className="mt-7 flex justify-end">
        <button disabled={!ready} onClick={onDone} className="h-11 rounded-xl bg-ink px-5 text-[14px] font-semibold text-white transition-opacity disabled:opacity-0">Show me my money</button>
      </div>
    </div>
  )
}

"""Local AI server for Almanac's chat. Loads Qwen3-0.6B once and serves it on :8787 (Vite proxies /api here).

    pip install -r llm/requirements.txt
    python3 llm/server.py          # or: npm run ai
"""
from __future__ import annotations

import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from service import parse_intent, write_reply

PORT = int(os.environ.get("PORT", "8787"))
HOST = os.environ.get("HOST", "0.0.0.0")
CORS_ORIGIN = os.environ.get("CORS_ORIGIN", "*")


def make_handler(llm):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, body: dict):
            data = json.dumps(body).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("access-control-allow-origin", CORS_ORIGIN)
            self.send_header("access-control-allow-headers", "content-type")
            self.send_header("access-control-allow-methods", "GET, POST, OPTIONS")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path == "/api/health":
                self._send(200, {"ok": True, "model": getattr(llm, "model_id", "stub"), "device": getattr(llm, "device", "n/a")})
            else:
                self._send(404, {"error": "not found"})

        def do_OPTIONS(self):
            self._send(204, {})

        def do_POST(self):
            try:
                payload = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))) or b"{}")
                if self.path == "/api/intent":
                    self._send(200, {"intent": parse_intent(llm, str(payload.get("message", "")))})
                elif self.path == "/api/chat":
                    self._send(200, write_reply(llm, payload))
                else:
                    self._send(404, {"error": "not found"})
            except Exception as e:  # the app treats any error as "use the built-in reply"
                self._send(500, {"error": str(e)})

        def log_message(self, fmt, *args):
            pass

    return Handler


def serve(llm, port: int = PORT) -> ThreadingHTTPServer:
    return ThreadingHTTPServer((HOST, port), make_handler(llm))


if __name__ == "__main__":
    from anthropic_chat import ClaudeChat

    model = ClaudeChat()
    print(f"Almanac AI on :{PORT} ({model.model_id} on {model.device})", flush=True)
    serve(model).serve_forever()

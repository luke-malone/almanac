"""Run with: python3 -m unittest discover -s llm   (no model or torch needed; the model is stubbed)."""
import json
import threading
import unittest
import urllib.request

import guards
from server import serve
from service import parse_intent, write_reply

FACTS = [
    "The person is asking about spending £100 on eating out and takeaway tonight.",
    "Without it: 23% chance of going below £0 at some point in the next 90 days. Lowest likely balance £192 around Sat 26 Dec.",
    "With it: 41% chance of going below £0. Lowest likely balance £92 around Sat 26 Dec.",
    "Moving a £250 cushion into the current account first would cut the chance of going below £0 to 12% even after this spend, and then up to £130 could be spent safely.",
    "A way to cut costs: Re-contract your broadband, worth £108 a year.",
]


class Stub:
    """Plays back canned model outputs, newest call last."""
    model_id, device = "stub", "n/a"

    def __init__(self, *outputs):
        self.outputs, self.calls = list(outputs), []

    def generate(self, messages, max_new_tokens=200, temperature=0.0):
        self.calls.append((messages, temperature))
        return self.outputs.pop(0) if self.outputs else ""


GOOD = "I’d hold off on that £100 tonight. Your chance of going below £0 would rise from 23% to 41%. Move the £250 cushion first and you could spend up to £130 safely, and re-contracting your broadband saves £108 a year."


class Guards(unittest.TestCase):
    def test_invented_figures_are_caught(self):
        self.assertEqual(guards.ungrounded_numbers(GOOD, "\n".join(FACTS)), [])
        self.assertEqual(guards.ungrounded_numbers("You will have £45 left and a 30% chance.", "\n".join(FACTS)), ["£45", "30%"])

    def test_small_bare_numbers_pass_but_big_ones_do_not(self):
        self.assertEqual(guards.ungrounded_numbers("Payday is on the 27th, in 3 weeks.", ""), [])
        self.assertEqual(guards.ungrounded_numbers("About 450 pounds.", ""), ["450"])

    def test_sign_and_commas(self):
        self.assertEqual(guards.ungrounded_numbers("You'd have £1,234.", "balance -£1,234"), [])

    def test_contradiction(self):
        self.assertTrue(guards.contradicts("hold", "Go ahead, you can afford it."))
        self.assertTrue(guards.contradicts("go", "I'd hold off on this."))
        self.assertFalse(guards.contradicts("hold", "I'd hold off on this."))
        # suggesting a safe amount after the cushion is not a contradiction of "hold off"
        self.assertFalse(guards.contradicts("hold", "Hold off now. After the cushion you can spend up to £145 safely."))

    def test_clean_strips_thinking_and_trims_cut_sentences(self):
        self.assertEqual(guards.clean("<think>hmm</think>Hello there."), "Hello there.")
        cut = "First sentence is long enough to keep here. Second sentence that got cut of"
        self.assertEqual(guards.clean(cut), "First sentence is long enough to keep here.")

    def test_extract_json_from_noise(self):
        self.assertEqual(guards.extract_json('Sure! ```json\n{"a": 1}\n``` done'), {"a": 1})
        self.assertIsNone(guards.extract_json("no json"))

    def test_intent_amount_must_be_in_the_message(self):
        msg = "i want to spend 100 pounds out tonight"
        ok = guards.validate_intent({"intent": "spend_check", "amount": 100, "category": "dining", "days_from_now": 0}, msg)
        self.assertEqual((ok["intent"], ok["amount"], ok["category"]), ("spend_check", 100, "dining"))
        # model hallucinated 500: replaced by what the person actually wrote
        self.assertEqual(guards.validate_intent({"intent": "spend_check", "amount": 500}, msg)["amount"], 100)
        # nothing usable anywhere: downgraded so the app uses its own reading
        self.assertEqual(guards.validate_intent({"intent": "spend_check", "amount": 500}, "should i go out")["intent"], "general")
        self.assertEqual(guards.validate_intent(None, "hi")["intent"], "general")

    def test_intent_rejects_junk_fields(self):
        v = guards.validate_intent({"intent": "spend_check", "amount": 50, "category": "yachts", "days_from_now": 400}, "spend £50")
        self.assertEqual((v["category"], v["days_from_now"]), ("other", 0))


class Service(unittest.TestCase):
    def test_parse_intent(self):
        llm = Stub('{"intent":"spend_check","amount":50,"category":"groceries","days_from_now":0}')
        self.assertEqual(parse_intent(llm, "is it worth it to spend 50 pounds on groceries")["category"], "groceries")

    def payload(self):
        return {"mode": "spend", "verdict": "hold", "verdictLine": "HOLD OFF.", "facts": FACTS,
                "messages": [{"role": "user", "content": "should I spend 100 pounds tonight?"}]}

    def test_good_reply_passes_and_prompt_carries_facts_and_decision(self):
        llm = Stub(GOOD)
        self.assertEqual(write_reply(llm, self.payload())["text"], GOOD)
        sent = llm.calls[0][0][-1]["content"]
        self.assertIn("23% chance", sent)
        self.assertIn("HOLD OFF", sent)

    def test_invented_number_then_retry_succeeds(self):
        llm = Stub("I'd hold off. You would be left with £45 on Friday, which is tight.", GOOD)
        self.assertEqual(write_reply(llm, self.payload())["text"], GOOD)
        self.assertEqual([t for _, t in llm.calls], [0.4, 0.1])

    def test_two_failures_give_none_so_app_uses_builtin_reply(self):
        r = write_reply(Stub("Go ahead, you can afford it.", "Sure, go ahead, that's fine."), self.payload())
        self.assertIsNone(r["text"])
        self.assertIn("contradicts", r["rejected"])


class Http(unittest.TestCase):
    def test_endpoints(self):
        llm = Stub('{"intent":"spend_check","amount":100,"category":"dining","days_from_now":0}', GOOD)
        srv = serve(llm, 0)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{srv.server_address[1]}"

        def post(path, body):
            req = urllib.request.Request(base + path, json.dumps(body).encode(), {"content-type": "application/json"})
            with urllib.request.urlopen(req) as r:
                return json.load(r)

        with urllib.request.urlopen(base + "/api/health") as r:
            self.assertTrue(json.load(r)["ok"])
        self.assertEqual(post("/api/intent", {"message": "spend £100 tonight?"})["intent"]["amount"], 100)
        self.assertEqual(post("/api/chat", Service.payload(None))["text"], GOOD)
        srv.shutdown()
        srv.server_close()


if __name__ == "__main__":
    unittest.main()

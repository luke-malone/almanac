import { useApp } from '../state'
import { dayLabel, money, money2, pct } from '../lib/format'
import { scoreBand } from '../engine/insights'
import { Button, Figure, Panel, Stat } from '../ui/kit'
import { ForecastChart } from '../ui/charts'
import { ActionRow } from './Savings'
import { HeadsUps, SpendCheck } from './widgets'

const int = (n: number) => String(Math.round(n))

function Hero() {
  const { score, scoreBefore, scoreParts, brief, persona, askChat, setView } = useApp()
  const delta = score - scoreBefore
  return (
    <section className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)] overflow-hidden rounded-2xl bg-[#24123F] text-white">
      <div className="p-6">
        <p className="text-[13px] text-[#B9AED3]">Financial resilience</p>
        <div className="mt-2 flex items-end gap-3">
          <p className="figure text-[64px]"><Figure value={score} fmt={int} /></p>
          <div className="pb-2">
            <p className="text-[15px] font-semibold">{scoreBand(score)}</p>
            <p className="text-[12.5px] text-[#B9AED3]">out of 100{delta > 0 && <span className="ml-1.5 font-semibold text-[#5EE0B5]">+{delta} since you started</span>}</p>
          </div>
        </div>
        <ul className="mt-5 space-y-2.5">
          {scoreParts.map((p) => (
            <li key={p.key} className="grid grid-cols-[110px_1fr_42px] items-center gap-3 text-[12.5px]" title={p.detail}>
              <span className="text-[#D9D1EA]">{p.label}</span>
              <span className="h-1.5 overflow-hidden rounded-full bg-white/10">
                <span className="block h-full rounded-full bg-[#5EE0B5] transition-[width] duration-700" style={{ width: `${(p.earned / p.max) * 100}%` }} />
              </span>
              <span className="tnum text-right text-[#B9AED3]">{p.earned}/{p.max}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="flex flex-col border-l border-white/10 bg-white/[0.03] p-6">
        <p className="text-[13px] text-[#B9AED3]">Your briefing for {dayLabel(new Date(2026, 10, 8))}</p>
        <p className="mt-1 text-[20px] font-semibold tracking-tight">Good evening, {persona.name}.</p>
        <ul className="mt-4 space-y-3">
          {brief.map((b, i) => (
            <li key={i} className="flex gap-3 text-[14px] leading-relaxed text-[#EDE8F6]">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#5EE0B5]" />{b}
            </li>
          ))}
        </ul>
        <div className="mt-auto flex flex-wrap gap-2 pt-5">
          <button onClick={() => setView('time')} className="rounded-lg bg-white px-3.5 py-2 text-[13px] font-semibold text-[#24123F] hover:bg-[#EDE8F6]">Open the time machine</button>
          <button onClick={() => askChat('What should I do first?')} className="rounded-lg border border-white/20 px-3.5 py-2 text-[13px] font-medium text-white hover:bg-white/10">What should I do first?</button>
        </div>
      </div>
    </section>
  )
}

export function Overview() {
  const s = useApp()
  if (s.simple) return <SimpleOverview />
  const { forecast, savedThisMonth, potentialYearly, progs, safe, actions, done, setView, nudges } = s
  const ptsBest = progs.reduce((a, p) => a + p.best, 0)
  const ptsCash = progs.reduce((a, p) => a + p.cash, 0)
  const next60 = forecast.days.slice(0, 60)
  const low = next60.reduce((w, d) => (d.p50 < w.p50 ? d : w))
  const risk = forecast.days.reduce((w, d) => (d.pNeg > w.pNeg ? d : w))
  const top = actions.filter((a) => !done.has(a.id) && (a.yearly > 0 || a.startBoost)).sort((a, b) => b.yearly - a.yearly).slice(0, 4)

  return (
    <div className="space-y-5">
      <Hero />

      <div className="grid grid-cols-4 gap-4">
        <Stat label="Saved this month" tone="gain" note="Clubcard Prices plus the actions you’ve taken">
          <Figure value={savedThisMonth} fmt={money2} />
        </Stat>
        <Stat label="Still available to you" note={<button className="text-brand hover:underline" onClick={() => setView('savings')}>{actions.filter((a) => a.counts && !done.has(a.id) && a.yearly > 0).length} actions waiting</button>}>
          <Figure value={potentialYearly} fmt={money} /><span className="ml-1 text-[14px] font-medium text-mute">/yr</span>
        </Stat>
        <Stat label="Your points are worth" tone="brand" note={`${money2(ptsCash)} as money off, up to ${money2(ptsBest)} used well`}>
          <Figure value={ptsBest} fmt={money} />
        </Stat>
        <Stat label="Room to save" tone={safe > 0 ? 'ink' : 'risk'} note={safe > 0 ? 'A month, keeping overdraft risk under 10%' : 'Christmas week is too tight'}>
          {safe > 0 ? <><Figure value={safe} fmt={money} /><span className="ml-1 text-[14px] font-medium text-mute">/mo</span></> : 'Not yet'}
        </Stat>
      </div>

      <div className="grid grid-cols-5 items-start gap-5">
        <Panel className="col-span-3" title="Your balance, next 60 days" aside={<button className="whitespace-nowrap text-brand hover:underline" onClick={() => setView('time')}>Time machine</button>}>
          <ForecastChart days={next60} height={190} marks={nudges.filter((n) => n.day < 60).map((n) => ({ day: n.day, tone: n.tone }))} />
          <p className="mt-3 text-[13.5px] leading-relaxed text-sub">
            Lowest point is likely <span className="font-semibold text-ink">{dayLabel(low.date)}</span>, around <span className="tnum font-semibold text-ink">{money(low.p50)}</span>.{' '}
            {risk.pNeg >= 0.05
              ? <>There’s a <span className="font-semibold text-risk">{pct(risk.pNeg)} chance</span> of going below £0 around {dayLabel(risk.date)}.</>
              : <>Very little chance of going overdrawn.</>}
          </p>
        </Panel>
        <div className="col-span-2"><SpendCheck /></div>
      </div>

      <div className="grid grid-cols-5 items-start gap-5">
        <Panel className="col-span-3" title="What I’d do next" aside={<Button size="sm" variant="secondary" onClick={() => setView('savings')}>See all</Button>}>
          <ul className="-my-3.5 divide-y divide-line">
            {top.map((a) => <ActionRow key={a.id} a={a} compact />)}
          </ul>
        </Panel>
        <div className="col-span-2"><HeadsUps limit={4} /></div>
      </div>
    </div>
  )
}

/** Plain-English view: four sentences and big buttons. For anyone who finds dashboards hard work. */
function SimpleOverview() {
  const { forecast, savedThisMonth, potentialYearly, progs, persona, setView, askChat, score } = useApp()
  const risk = forecast.days.reduce((w, d) => (d.pNeg > w.pNeg ? d : w))
  const pts = progs.reduce((a, p) => a + p.best, 0)
  const rows = [
    { big: risk.pNeg >= 0.1 ? `Money is tight around ${dayLabel(risk.date)}.` : 'You’re safe until payday.', small: risk.pNeg >= 0.1 ? `There’s a ${pct(risk.pNeg)} chance you go overdrawn. Two small changes fix it.` : 'Nothing to worry about in the next 90 days.', cta: 'Show me', go: () => setView('time') },
    { big: `You’ve saved ${money2(savedThisMonth)} this month.`, small: 'From shop prices and the changes you’ve made.', cta: 'See savings', go: () => setView('savings') },
    { big: `You could keep ${money(potentialYearly)} more a year.`, small: 'Mostly bills you’re overpaying and card rewards you’re missing.', cta: 'Show me how', go: () => setView('savings') },
    { big: `Your points are worth up to ${money(pts)}.`, small: 'Spend them at the right time and they go twice as far.', cta: 'See points', go: () => setView('cards') },
  ]
  return (
    <div className="space-y-4">
      <header>
        <h1 className="text-[30px] font-semibold tracking-tight">Hi {persona.name}. Here’s your money in plain English.</h1>
        <p className="mt-1 text-[16px] text-sub">Your resilience score is <span className="font-semibold text-ink">{score} out of 100</span>.</p>
      </header>
      {rows.map((r) => (
        <div key={r.big} className="flex items-center justify-between gap-6 rounded-2xl border border-line bg-surface px-6 py-5">
          <div>
            <p className="text-[22px] font-semibold tracking-tight">{r.big}</p>
            <p className="mt-1 text-[16px] text-sub">{r.small}</p>
          </div>
          <button onClick={r.go} className="h-12 shrink-0 rounded-xl bg-ink px-6 text-[16px] font-semibold text-white">{r.cta}</button>
        </div>
      ))}
      <button onClick={() => askChat('What should I do first?')} className="w-full rounded-2xl border-2 border-dashed border-line py-5 text-[17px] font-medium text-brand hover:border-brand">Ask: what should I do first?</button>
    </div>
  )
}

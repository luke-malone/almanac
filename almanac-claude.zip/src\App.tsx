import { useEffect, useRef } from 'react'
import { Provider, useApp, type View } from './state'
import { animate, reducedMotion } from './lib/motion'
import { money2 } from './lib/format'
import { Overview } from './views/Overview'
import { TimeMachine } from './views/TimeMachine'
import { Cards } from './views/Cards'
import { Savings } from './views/Savings'
import { Invest } from './views/Invest'
import { Trust } from './views/Trust'
import { HowItWorks } from './views/HowItWorks'
import { ScriptModal } from './views/widgets'
import { Notes } from './ui/Notes'
import { Chat } from './ui/Chat'
import { Onboarding } from './ui/Onboarding'
import { Palette } from './ui/Palette'

export default function App() {
  return (
    <Provider>
      <Shell />
    </Provider>
  )
}

const NAV: { id: View; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'time', label: 'Time machine' },
  { id: 'savings', label: 'Savings and discounts' },
  { id: 'cards', label: 'Cards and points' },
  { id: 'invest', label: 'Investments and cash' },
  { id: 'trust', label: 'Privacy and safety' },
  { id: 'how', label: 'How it works' },
]

function Switch({ on, onChange, label }: { on: boolean; onChange: () => void; label: string }) {
  return (
    <button role="switch" aria-checked={on} onClick={onChange} className="flex w-full items-center justify-between rounded-lg px-3 py-1.5 text-[13px] text-sub hover:bg-line-2">
      {label}
      <span className={`relative h-5 w-9 rounded-full transition-colors ${on ? 'bg-brand' : 'bg-[#d0d5dd]'}`}>
        <span className={`absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-4' : ''}`} />
      </span>
    </button>
  )
}

function Shell() {
  const { view, setView, persona, savedThisMonth, score, toast, onboarded, simple, setSimple, large, setLarge, setPaletteOpen, resetDemo, notes, setNotes } = useApp()
  const main = useRef<HTMLDivElement>(null)
  const toastRef = useRef<HTMLDivElement>(null)
  const isMac = typeof navigator !== 'undefined' && /Mac/.test(navigator.platform)

  useEffect(() => {
    main.current?.scrollTo({ top: 0 })
    if (main.current?.firstElementChild && !reducedMotion()) animate(main.current.firstElementChild, { opacity: [0, 1], translateY: [6, 0], duration: 420, ease: 'outQuint' })
  }, [view, simple])
  useEffect(() => {
    if (toast && toastRef.current && !reducedMotion()) animate(toastRef.current, { opacity: [0, 1], translateY: [12, 0], duration: 360, ease: 'outQuint' })
  }, [toast])

  return (
    <div className="flex h-full min-w-[1180px]" style={{ zoom: large ? 1.1 : 1 }}>
      <nav className="flex w-[220px] shrink-0 flex-col border-r border-line bg-surface px-4 py-5" aria-label="Sections">
        <div className="px-2">
          <p className="text-[17px] font-semibold tracking-tight">Almanac</p>
          <p className="text-[12.5px] text-mute">The wealth manager for everyone else</p>
        </div>
        <button onClick={() => setPaletteOpen(true)} className="mt-5 flex items-center justify-between rounded-lg border border-line px-3 py-2 text-[13px] text-mute hover:border-[#c7ccd4] hover:text-ink">
          Search or ask <kbd className="rounded border border-line px-1.5 text-[11px]">{isMac ? '⌘' : 'Ctrl'} K</kbd>
        </button>
        <ul className="mt-4 space-y-0.5">
          {NAV.map((n) => (
            <li key={n.id}>
              <button onClick={() => setView(n.id)} aria-current={view === n.id ? 'page' : undefined}
                className={`w-full rounded-lg px-3 py-2 text-left text-[14px] transition-colors ${view === n.id ? 'bg-brand-soft font-semibold text-brand' : 'text-sub hover:bg-line-2 hover:text-ink'}`}>
                {n.label}
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-gain-soft px-3 py-2.5">
            <p className="text-[11.5px] text-gain">Saved this month</p>
            <p className="figure mt-1 text-[18px] text-gain">{money2(savedThisMonth)}</p>
          </div>
          <div className="rounded-xl bg-brand-soft px-3 py-2.5">
            <p className="text-[11.5px] text-brand">Resilience</p>
            <p className="figure mt-1 text-[18px] text-brand">{score}<span className="text-[12px] font-medium">/100</span></p>
          </div>
        </div>
        <div className="mt-auto space-y-0.5 border-t border-line pt-3">
          <Switch on={simple} onChange={() => setSimple(!simple)} label="Simple view" />
          <Switch on={large} onChange={() => setLarge(!large)} label="Larger text" />
          <Switch on={notes} onChange={() => setNotes(!notes)} label="Speaker notes (N)" />
          <button onClick={resetDemo} className="w-full rounded-lg px-3 py-1.5 text-left text-[13px] text-sub hover:bg-line-2">Reset demo</button>
          <div className="px-3 pt-3">
            <p className="text-[13.5px] font-semibold">{persona.name}, {persona.age}</p>
            <p className="text-[12px] leading-snug text-mute">{persona.role}, {persona.city}. Demo account with synthetic Open Banking data.</p>
          </div>
        </div>
      </nav>

      <main ref={main} className="thin-scroll min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-[1100px] px-6 py-6 min-[1400px]:px-8">
          {view === 'overview' && <Overview />}
          {view === 'time' && <TimeMachine />}
          {view === 'savings' && <Savings />}
          {view === 'cards' && <Cards />}
          {view === 'invest' && <Invest />}
          {view === 'trust' && <Trust />}
          {view === 'how' && <HowItWorks />}
          <p className="mt-8 border-t border-line pt-4 text-[11.5px] leading-relaxed text-mute">
            Almanac is a hackathon prototype using synthetic data. It gives guidance, not personal financial advice. Investments can fall as well as rise. In production it would operate under an FCA-authorised firm’s permissions for Open Banking and targeted support.
          </p>
        </div>
      </main>

      <Chat />
      <Palette />
      <ScriptModal />
      <Notes />
      {!onboarded && <Onboarding />}

      {toast && (
        <div className="pointer-events-none fixed inset-x-0 bottom-6 z-50 flex justify-center">
          <div ref={toastRef} role="status" className="pointer-events-auto flex items-center gap-4 rounded-xl bg-ink px-4 py-3 text-[14px] font-medium text-white shadow-xl">
            {toast.text}
            {toast.undo && <button onClick={toast.undo} className="text-[13px] font-semibold text-[#5EE0B5] hover:underline">Undo</button>}
          </div>
        </div>
      )}
    </div>
  )
}

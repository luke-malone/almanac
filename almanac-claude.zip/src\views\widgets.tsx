// Small pieces shared by several screens: the spend checker, heads-ups list and the "do it for me" modal.
import { useState } from 'react'
import { useApp } from '../state'
import { runWhatIf, type SpendCategory, type WhatIf } from '../ai/whatif'
import { dayLabel, money, pct } from '../lib/format'
import { Badge, Button, Modal, Panel } from '../ui/kit'
import { MiniChart } from '../ui/charts'
import type { Nudge } from '../engine/nudges'

const CATS: { id: SpendCategory; label: string; noun: string }[] = [
  { id: 'dining', label: 'Going out', noun: 'going out' },
  { id: 'groceries', label: 'Groceries', noun: 'groceries' },
  { id: 'shopping', label: 'Shopping', noun: 'shopping' },
  { id: 'travel', label: 'Travel', noun: 'travel' },
  { id: 'other', label: 'Something else', noun: 'something' },
]
const WHEN = [{ d: 0, label: 'Today' }, { d: 1, label: 'Tomorrow' }, { d: 6, label: 'Saturday' }, { d: 14, label: 'In 2 weeks' }]
const VERDICT: Record<WhatIf['verdict'], { label: string; tone: 'gain' | 'brand' | 'risk' | 'mute' }> = {
  go: { label: 'Go ahead', tone: 'gain' },
  careful: { label: 'Go carefully', tone: 'brand' },
  hold: { label: 'Hold off for now', tone: 'risk' },
  essential: { label: 'It’s a need: buy it', tone: 'gain' },
}

/** "Thinking of spending?" Re-runs the 400-path forecast with the spend added, in the browser. */
export function SpendCheck() {
  const s = useApp()
  const [amount, setAmount] = useState('100')
  const [cat, setCat] = useState<SpendCategory>('dining')
  const [days, setDays] = useState(0)
  const [w, setW] = useState<WhatIf | null>(null)
  const check = () => {
    const a = Math.min(5000, Math.max(1, parseFloat(amount) || 0))
    setW(runWhatIf(s, { amount: a, category: cat, daysFromNow: days }))
  }
  const field = 'h-10 rounded-lg border border-line bg-surface px-3 text-[14px] outline-none focus:border-brand'
  const v = w ? VERDICT[w.verdict] : null
  return (
    <Panel title="Thinking of spending?">
      <form onSubmit={(e) => { e.preventDefault(); check() }} className="grid grid-cols-[84px_minmax(0,1fr)] gap-2">
        <label className="relative">
          <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-[14px] text-mute">£</span>
          <input aria-label="Amount" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} className={`${field} w-full pl-6`} />
        </label>
        <select aria-label="What on" value={cat} onChange={(e) => setCat(e.target.value as SpendCategory)} className={`${field} w-full min-w-0`}>
          {CATS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
        </select>
        <select aria-label="When" value={days} onChange={(e) => setDays(+e.target.value)} className={`${field} w-full min-w-0`}>
          {WHEN.map((x) => <option key={x.d} value={x.d}>{x.label}</option>)}
        </select>
        <Button type="submit">Check it</Button>
      </form>
      {w && v ? (
        <div className="mt-4">
          <div className="flex items-center justify-between">
            <span className="whitespace-nowrap"><Badge tone={v.tone}>{v.label}</Badge></span>
            <span className="tnum text-right text-[12.5px] text-mute">Below £0: {pct(w.before.pAny)} → <span className={w.after.pAny >= 0.15 ? 'font-semibold text-risk' : 'font-semibold text-ink'}>{pct(w.after.pAny)}</span></span>
          </div>
          <div className="mt-2"><MiniChart series={w.series} /></div>
          <p className="mt-2 text-[12.5px] leading-relaxed text-sub">
            Lowest likely balance {money(w.before.low)} → <span className="font-semibold text-ink">{money(w.after.low)}</span> around {dayLabel(w.after.lowDate)}.
            {w.cushion ? ` With the £250 cushion first, you could spend up to ${money(w.cushion.safe)} safely.` : w.safeNow > 0 && w.verdict !== 'go' ? ` Up to ${money(w.safeNow)} is safe.` : ''}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" onClick={() => s.askChat(`I want to spend £${w.intent.amount} on ${CATS.find((c) => c.id === cat)?.noun} ${days === 0 ? 'today' : days === 1 ? 'tomorrow' : `in ${days} days`}. Should I?`)}>Ask the wealth manager why</Button>
            {w.cushion && <Button size="sm" variant="ghost" onClick={() => { s.complete(w.cushion!.id); setW(null) }}>Move the £250 cushion</Button>}
          </div>
        </div>
      ) : (
        <p className="mt-4 text-[13px] leading-relaxed text-sub">Almanac re-runs your 90-day forecast with the spend added: what it does to your lowest balance, your overdraft risk, and what would make it safe.</p>
      )}
    </Panel>
  )
}

const TONE: Record<Nudge['tone'], string> = { warn: 'bg-risk', good: 'bg-gain', info: 'bg-brand' }

export function HeadsUps({ limit = 5 }: { limit?: number }) {
  const { nudges, complete, setScriptFor, actions, done } = useApp()
  return (
    <Panel title="What I’ll warn you about, and when" aside="Before it happens, not after">
      <ul className="space-y-3">
        {nudges.slice(0, limit).map((n) => {
          const a = n.actionId ? actions.find((x) => x.id === n.actionId) : undefined
          return (
            <li key={n.id} className="flex gap-3">
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${TONE[n.tone]}`} />
              <div className="min-w-0 flex-1">
                <p className="text-[12px] text-mute">{n.day === 0 ? 'Today' : dayLabel(n.date)}</p>
                <p className="text-[13.5px] font-semibold leading-snug">{n.title}</p>
                <p className="text-[12.5px] leading-relaxed text-sub">{n.body}</p>
                {a && !done.has(a.id) && n.actionLabel && (
                  <button onClick={() => (a.script && n.actionLabel?.startsWith('Show') ? setScriptFor(a.id) : complete(a.id))}
                    className="mt-1 text-[12.5px] font-medium text-brand hover:underline">{n.actionLabel}</button>
                )}
              </div>
            </li>
          )
        })}
      </ul>
    </Panel>
  )
}

/** The "do it for me" script for one action. */
export function ScriptModal() {
  const { scriptFor, setScriptFor, actions, done, complete } = useApp()
  const [copied, setCopied] = useState(false)
  const a = actions.find((x) => x.id === scriptFor)
  if (!a?.script) return null
  const text = `${a.title}\n\n${a.script.lines.map((l, i) => `${i + 1}. ${l}`).join('\n')}`
  return (
    <Modal open onClose={() => { setScriptFor(null); setCopied(false) }} title={a.title}>
      <p className="text-[13.5px] text-sub">{a.script.how}{a.yearly > 0 && <> Worth <span className="font-semibold text-gain">{money(a.yearly)} a year</span>.</>}</p>
      <ol className="mt-4 space-y-3">
        {a.script.lines.map((l, i) => (
          <li key={i} className="flex gap-3 text-[14.5px] leading-relaxed">
            <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft text-[12px] font-semibold text-brand">{i + 1}</span>{l}
          </li>
        ))}
      </ol>
      <div className="mt-6 flex items-center justify-between">
        <Button size="sm" variant="secondary" onClick={() => { navigator.clipboard?.writeText(text).then(() => setCopied(true), () => setCopied(false)) }}>{copied ? 'Copied' : 'Copy the steps'}</Button>
        {done.has(a.id)
          ? <Badge tone="gain">Done</Badge>
          : <Button size="sm" onClick={() => { complete(a.id); setScriptFor(null) }}>I’ve done it</Button>}
      </div>
    </Modal>
  )
}

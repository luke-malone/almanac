import { animate, createTimeline, stagger } from 'animejs'

export const reducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

/** Count a number up/down inside an element. */
export function countTo(el: HTMLElement | null, from: number, to: number, fmt: (n: number) => string, duration = 1100) {
  if (!el) return
  if (reducedMotion()) { el.textContent = fmt(to); return }
  const o = { v: from }
  animate(o, {
    v: to,
    duration,
    ease: 'outExpo',
    onUpdate: () => { el.textContent = fmt(o.v) },
  })
}

export function rise(targets: string | Element | Element[] | NodeListOf<Element>, delay = 0) {
  if (reducedMotion()) return
  animate(targets as never, {
    opacity: [0, 1],
    translateY: [10, 0],
    duration: 600,
    delay: stagger(45, { start: delay }),
    ease: 'outQuint',
  })
}

export function pop(el: Element | null) {
  if (!el || reducedMotion()) return
  animate(el, { scale: [1, 1.06, 1], duration: 520, ease: 'outBack(2)' })
}

export { animate, createTimeline, stagger }

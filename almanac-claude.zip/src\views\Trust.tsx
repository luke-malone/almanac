import { useState } from 'react'
import { useApp } from '../state'
import { Badge, Button, Panel } from '../ui/kit'

const HELP = [
  { name: 'MoneyHelper', what: 'Free, impartial money and debt guidance, backed by the government.', url: 'https://www.moneyhelper.org.uk' },
  { name: 'StepChange', what: 'Free debt advice charity. Can set up a debt management plan.', url: 'https://www.stepchange.org' },
  { name: 'National Debtline', what: 'Free, confidential debt advice by phone and online.', url: 'https://nationaldebtline.org' },
  { name: 'Citizens Advice', what: 'Help with benefits, bills, housing and debt, in person or online.', url: 'https://www.citizensadvice.org.uk' },
]

export function Trust() {
  const { exportData, resetDemo, flash } = useApp()
  const [confirm, setConfirm] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)

  const download = () => {
    const data = exportData()
    try {
      const url = URL.createObjectURL(new Blob([data], { type: 'application/json' }))
      const a = document.createElement('a')
      a.href = url
      a.download = 'almanac-my-data.json'
      a.click()
      URL.revokeObjectURL(url)
      flash('Your data has been downloaded')
    } catch {
      setCopied(data)
    }
  }

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-[26px] font-semibold tracking-tight">Privacy and safety</h1>
        <p className="mt-1 text-[14px] text-sub">How Almanac stays on your side, what it can and can’t do, and where to get help.</p>
      </header>

      <div className="grid grid-cols-2 gap-5">
        <Panel title="Almanac’s promises">
          <ul className="space-y-3 text-[13.5px] leading-relaxed text-sub">
            <li><span className="font-semibold text-ink">It never suggests borrowing.</span> No loans, no buy now pay later, no overdrafts, and never spending more to earn points or a bonus.</li>
            <li><span className="font-semibold text-ink">It only works with cards you already have.</span> It won’t recommend you apply for credit. Recommending credit products is credit broking, which is regulated.</li>
            <li><span className="font-semibold text-ink">Debt comes first.</span> If you’re paying interest on a card, it tells you to clear that before anything else, and stops showing rewards for that card.</li>
            <li><span className="font-semibold text-ink">Every number can be checked.</span> Each suggestion links to the transactions or the published rule it comes from. Estimates are labelled.</li>
            <li><span className="font-semibold text-ink">No commission.</span> Nothing Almanac suggests is paid for by a provider.</li>
          </ul>
        </Panel>

        <Panel title="Guidance, not advice" aside={<Badge tone="brand">UK rules</Badge>}>
          <div className="space-y-3 text-[13.5px] leading-relaxed text-sub">
            <p>Almanac gives guidance designed for people in a similar situation. It doesn’t make personal recommendations about specific investments, and it never names a fund or provider. Personal investment advice needs FCA authorisation.</p>
            <p>Since 6 April 2026, the FCA’s <span className="font-medium text-ink">targeted support</span> rules let authorised firms, such as banks, give ready-made suggestions to groups of customers with common needs, without full financial advice. In real use, Almanac would run under a bank’s FCA permissions in exactly this way.</p>
            <div className="rounded-xl bg-risk-soft px-4 py-3 text-[#7a271a]">
              <p className="font-semibold">Capital at risk</p>
              <p>Investments can go down as well as up, and you may get back less than you put in. Projections are illustrations, not guarantees. Past performance isn’t a reliable guide to the future.</p>
            </div>
          </div>
        </Panel>
      </div>

      <Panel title="The rules Almanac works to" aside="Checked November 2026">
        <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-[13.5px] leading-relaxed text-sub">
          <p><span className="font-semibold text-ink">ISA allowance.</span> £20,000 a year across all your ISAs (2026/27). From 6 April 2027, under-65s can put at most £12,000 of that into cash ISAs.</p>
          <p><span className="font-semibold text-ink">Lifetime ISA.</span> Open between 18 and 39. Pay in up to £4,000 a year (part of the £20,000) and get a 25% government bonus. Use it for a first home costing up to £450,000, or after 60.</p>
          <p><span className="font-semibold text-ink">Lifetime ISA charge.</span> Taking money out for anything else costs 25%, so you can get back less than you paid in. Since 29 October 2026 it’s 20% for a first home above £450,000.</p>
          <p><span className="font-semibold text-ink">What’s changing.</span> From April 2029 a First Time Buyer ISA replaces the Lifetime ISA for new savers. Lifetime ISAs opened before then carry on.</p>
          <p><span className="font-semibold text-ink">Emergency money.</span> Almanac always keeps your emergency fund in easy-access cash, never invested.</p>
          <p><span className="font-semibold text-ink">Fair treatment.</span> Built around the FCA’s Consumer Duty: avoid foreseeable harm, explain clearly, support customers in financial difficulty.</p>
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-5">
        <Panel title="Your data">
          <ul className="space-y-2 text-[13.5px] leading-relaxed text-sub">
            <li><span className="font-semibold text-ink">Read-only.</span> Almanac connects through Open Banking. It can see balances and transactions. It can’t move money or see your passwords.</li>
            <li><span className="font-semibold text-ink">90-day consent.</span> You choose to renew it, and you can disconnect at any time.</li>
            <li><span className="font-semibold text-ink">Used for one thing.</span> Your data is only used to give you guidance, under UK GDPR. It is never sold.</li>
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" onClick={download}>Download my data</Button>
            {confirm
              ? <Button size="sm" onClick={() => { resetDemo() }}>Yes, delete everything</Button>
              : <Button size="sm" variant="secondary" onClick={() => setConfirm(true)}>Delete my data and disconnect</Button>}
          </div>
          {copied && <textarea readOnly className="mt-3 h-32 w-full rounded-lg border border-line p-2 font-mono text-[11px]" value={copied} aria-label="Your data" />}
        </Panel>

        <Panel title="If money gets hard">
          <p className="text-[13.5px] leading-relaxed text-sub">Talking to someone early makes a real difference. These services are free and won’t judge you.</p>
          <ul className="mt-3 divide-y divide-line">
            {HELP.map((h) => (
              <li key={h.name} className="py-2.5">
                <a href={h.url} target="_blank" rel="noreferrer" className="text-[14px] font-semibold text-brand hover:underline">{h.name}</a>
                <p className="text-[13px] text-sub">{h.what} <span className="text-mute">{h.url.replace('https://', '')}</span></p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[13px] leading-relaxed text-sub">In England and Wales, a debt adviser can apply for <span className="font-medium text-ink">Breathing Space</span>, which pauses most interest, charges and enforcement for up to 60 days.</p>
        </Panel>
      </div>
    </div>
  )
}

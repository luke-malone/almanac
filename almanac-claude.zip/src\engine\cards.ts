// Cards & points optimiser.
// Works out where each kind of spending should go, what every points balance is
// worth, whether sign-up bonuses are reachable with normal spending, and when a
// card is costing more in interest than it could ever earn.
import type { Persona } from '../data/types'

export type Scheme = 'Cashback' | 'Avios' | 'Membership Rewards' | 'Tesco Clubcard' | 'Nectar' | 'None'
export type Category = 'groceries' | 'travel' | 'dining' | 'shopping' | 'bills'

export interface Card {
  id: string
  name: string
  network: 'Visa' | 'Mastercard' | 'Amex'
  last4: string
  scheme: Scheme
  /** points (or pence of cashback) per £1, by category; `base` applies elsewhere */
  earn: { base: number } & Partial<Record<Category, number>>
  annualFee: number
  balance: number
  apr: number
  paysInFull: boolean
  pointsBalance: number
  bonus?: { points: number; spendRequired: number; spentSoFar: number; daysLeft: number }
  tone: string
  /** share of card-able spending currently going on this card */
  currentShare?: number
}

/** pence per point. `cash` = easiest redemption, `best` = best common use. */
export const POINT_VALUES: Record<Scheme, { cash: number; best: number; bestUse: string; cashUse: string }> = {
  Cashback: { cash: 1, best: 1, bestUse: 'Cash in your account', cashUse: 'Cash' },
  Avios: { cash: 0.6, best: 1.0, bestUse: 'Off-peak reward flights', cashUse: 'Part-pay a flight' },
  'Membership Rewards': { cash: 0.5, best: 1.0, bestUse: 'Transfer to Avios 1:1', cashUse: 'Statement credit' },
  'Tesco Clubcard': { cash: 1, best: 2, bestUse: 'Reward Partners, up to 2×', cashUse: 'Money off at Tesco' },
  Nectar: { cash: 0.5, best: 0.5, bestUse: 'Money off at Sainsbury’s', cashUse: 'Money off at Sainsbury’s' },
  None: { cash: 0, best: 0, bestUse: '', cashUse: '' },
}

export const CATEGORY_LABEL: Record<Category, string> = {
  groceries: 'Groceries',
  travel: 'Travel and commuting',
  dining: 'Eating out and takeaway',
  shopping: 'Shopping',
  bills: 'Subscriptions and bills',
}

const MCC: Record<string, Category> = {
  '5411': 'groceries', '4112': 'travel', '5814': 'dining', '5812': 'dining', '5311': 'shopping',
  '4899': 'bills', '4814': 'bills', '5815': 'bills', '7997': 'bills', '4900': 'bills',
}

export const DEFAULT_CARDS: Card[] = [
  {
    id: 'c1', name: 'Everyday Cashback', network: 'Mastercard', last4: '4417', scheme: 'Cashback',
    earn: { base: 0.5 }, annualFee: 0, balance: 412.6, apr: 24.9, paysInFull: true, pointsBalance: 820,
    tone: 'linear-gradient(135deg,#334155,#0f172a)', currentShare: 1,
  },
  {
    id: 'c2', name: 'Skyward Avios', network: 'Visa', last4: '0932', scheme: 'Avios',
    earn: { base: 1, travel: 1.5 }, annualFee: 0, balance: 0, apr: 29.9, paysInFull: true, pointsBalance: 6400,
    bonus: { points: 5000, spendRequired: 1000, spentSoFar: 180, daysLeft: 64 },
    tone: 'linear-gradient(135deg,#1e3a8a,#172554)', currentShare: 0,
  },
]

/** Templates for the "Add a card" form. Fictional cards, realistic terms. */
export const CARD_TEMPLATES: Omit<Card, 'id' | 'last4' | 'balance' | 'pointsBalance' | 'paysInFull'>[] = [
  { name: 'Aurora Rewards', network: 'Amex', scheme: 'Membership Rewards', earn: { base: 1, travel: 2, dining: 2 }, annualFee: 0, apr: 30.7, tone: 'linear-gradient(135deg,#0f766e,#134e4a)' },
  { name: 'Grocer Plus', network: 'Mastercard', scheme: 'Tesco Clubcard', earn: { base: 0.25, groceries: 0.5 }, annualFee: 0, apr: 24.9, tone: 'linear-gradient(135deg,#1d4ed8,#1e3a8a)' },
  { name: 'Simple Cashback', network: 'Visa', scheme: 'Cashback', earn: { base: 1 }, annualFee: 25, apr: 26.9, tone: 'linear-gradient(135deg,#7c3aed,#4c1d95)' },
  { name: 'Builder Card (no rewards)', network: 'Mastercard', scheme: 'None', earn: { base: 0 }, annualFee: 0, apr: 34.9, tone: 'linear-gradient(135deg,#475569,#1e293b)' },
]

export function spendByCategory(p: Persona) {
  const months = 3
  const out: Record<Category, number> = { groceries: 0, travel: 0, dining: 0, shopping: 0, bills: 0 }
  p.history.forEach((t) => {
    const c = t.mcc ? MCC[t.mcc] : undefined
    if (c && t.amount < 0) out[c] += -t.amount / months
  })
  // the existing card statement is mostly shopping we can't see line by line
  const cardStatements = p.history.filter((t) => /CARD PAYMENT/.test(t.info))
  out.shopping += cardStatements.reduce((s, t) => s - t.amount, 0) / months
  for (const k of Object.keys(out) as Category[]) out[k] = Math.round(out[k])
  return out
}

const valuePerPound = (c: Card, cat: Category) => ((c.earn[cat] ?? c.earn.base) * POINT_VALUES[c.scheme].best) / 100

export interface CardPlan {
  rows: { cat: Category; monthly: number; best: Card | null; rate: number; yearly: number }[]
  optimisedYearly: number
  currentYearly: number
  gain: number
  warnings: { card: Card; interestYearly: number }[]
  bonuses: { card: Card; onTrack: boolean; projected: number; valuePounds: number }[]
}

export function planCards(cards: Card[], spend: Record<Category, number>): CardPlan {
  const safe = cards.filter((c) => c.paysInFull)
  const rows = (Object.keys(spend) as Category[]).map((cat) => {
    let best: Card | null = null
    let rate = 0
    for (const c of safe) {
      const v = valuePerPound(c, cat)
      if (v > rate) { rate = v; best = c }
    }
    return { cat, monthly: spend[cat], best, rate, yearly: spend[cat] * 12 * rate }
  })
  const total = Object.values(spend).reduce((a, b) => a + b, 0)
  const fees = safe.filter((c) => rows.some((r) => r.best?.id === c.id)).reduce((s, c) => s + c.annualFee, 0)
  const optimisedYearly = rows.reduce((s, r) => s + r.yearly, 0) - fees
  // today: only the statement spending goes on a card, split by currentShare
  const cardSpend = spend.shopping
  const currentYearly = cards.reduce((s, c) => s + cardSpend * 12 * (c.currentShare ?? 0) * (c.earn.base * POINT_VALUES[c.scheme].best) / 100, 0)
    - cards.filter((c) => (c.currentShare ?? 0) > 0).reduce((s, c) => s + c.annualFee, 0)
  const warnings = cards.filter((c) => !c.paysInFull && c.balance > 0).map((card) => ({ card, interestYearly: card.balance * card.apr / 100 }))
  const bonuses = cards.filter((c) => c.bonus && c.paysInFull).map((card) => {
    const b = card.bonus!
    const routed = rows.filter((r) => r.best?.id === card.id).reduce((s, r) => s + r.monthly, 0)
    const projected = b.spentSoFar + (routed || total * 0.5) * (b.daysLeft / 30)
    return { card, onTrack: projected >= b.spendRequired, projected, valuePounds: b.points * POINT_VALUES[card.scheme].best / 100 }
  })
  void total
  return { rows, optimisedYearly, currentYearly, gain: Math.max(0, optimisedYearly - currentYearly), warnings, bonuses }
}

export interface Program { scheme: Scheme; balance: number; cash: number; best: number; bestUse: string; cashUse: string; from: string[] }

export function programs(p: Persona, cards: Card[]): Program[] {
  const map = new Map<Scheme, Program>()
  const add = (scheme: Scheme, balance: number, from: string) => {
    if (scheme === 'None' || balance <= 0) return
    const v = POINT_VALUES[scheme]
    const cur = map.get(scheme) ?? { scheme, balance: 0, cash: 0, best: 0, bestUse: v.bestUse, cashUse: v.cashUse, from: [] }
    cur.balance += balance
    cur.cash = (cur.balance * v.cash) / 100
    cur.best = (cur.balance * v.best) / 100
    cur.from.push(from)
    map.set(scheme, cur)
  }
  cards.forEach((c) => add(c.scheme, c.pointsBalance, c.name))
  p.points.forEach((x) => add(x.scheme as Scheme, x.balance, 'Loyalty card'))
  return [...map.values()].sort((a, b) => b.best - a.best)
}

/** Seasonal redemption idea: points go further off-peak. Prices illustrative. */
export function tripIdea(progs: Program[], plan: CardPlan) {
  const avios = progs.find((p) => p.scheme === 'Avios')?.balance ?? 0
  const bonus = plan.bonuses.find((b) => b.card.scheme === 'Avios' && b.onTrack)?.card.bonus?.points ?? 0
  const byFeb = Math.round(avios + bonus + 1.0 * 450 * 2.5)
  return {
    avios,
    byFeb,
    need: 9000,
    text: `Late January to mid-February is off-peak. An off-peak short-haul return (for example Manchester to Dublin, or London to Amsterdam) is roughly 9,000 Avios plus fees. The same seat at February half-term costs noticeably more.`,
  }
}

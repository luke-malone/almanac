// "Financial time travel": an ensemble forecast of the account balance.
// Same idea as a weather ensemble — run the next 90 days hundreds of times with
// realistic randomness, then report the spread and the chance of going below £0.
import { addDays, TODAY } from '../lib/dates'
import { mulberry32, normal } from '../lib/rng'
import type { Persona } from '../data/types'
import type { Learned } from './learn'

export type Level = 0 | 1 | 2 | 3 // sun, cloud, rain, storm

export interface DayStat {
  i: number
  date: Date
  p10: number
  p25: number
  p50: number
  p75: number
  p90: number
  pNeg: number
  level: Level
}

export interface Forecast {
  days: DayStat[]
  pAnyNeg: number
  /** mean Universal Credit payment by pay date (iso) */
  ucByMonth: { date: Date; mean: number }[]
  /** mean platform earnings per UC assessment period */
  worstDay: DayStat
}

export interface Override {
  /** which recurring item this changes */
  match: (r: { merchant: string; mcc?: string }) => boolean
  /** new amount (signed, e.g. -10 for a £10 bill) */
  amount: number
  from: Date
}

export interface Shocks {
  /** irregular income (e.g. bank shifts) stops */
  noIrregularIncome?: boolean
  /** unexpected one-off costs */
  oneOffs?: { date: Date; amount: number }[]
  /** rent rises by this fraction from January */
  rentRise?: number
}

export interface SimOptions {
  moves: Set<string>
  overrides?: Override[]
  monthlySaving: number // Help to Save / LISA / investing transfer
  startBoost?: number // one-off transfer into the current account today
  shocks?: Shocks
  horizon?: number
  paths?: number
  seed?: number
}

export const levelOf = (p: number): Level => (p < 0.05 ? 0 : p < 0.15 ? 1 : p < 0.3 ? 2 : 3)

const COUNCIL_TAX_FREE_MONTHS = [1, 2] // Feb, Mar — 10-instalment default

export function simulate(persona: Persona, L: Learned, o: SimOptions): Forecast {
  const H = o.horizon ?? 90
  const N = o.paths ?? 400
  const rng = mulberry32(o.seed ?? 7)
  const balances: Float64Array[] = Array.from({ length: H }, () => new Float64Array(N))
  const has = (id: string) => o.moves.has(id)
  let anyNeg = 0

  // UC assessment-period earnings already banked in history
  const uc = persona.uc
  const apKey = (d: Date) => {
    // AP runs from apStartDay of one month to the day before it in the next; key = month it ends in
    const m = d.getFullYear() * 12 + d.getMonth()
    return uc && d.getDate() >= uc.apStartDay ? m + 1 : m
  }
  const histEarnings = new Map<number, number>()
  const payouts = L.recurring.find((r) => r.isIncome && r.period === 'weekly')
  if (uc && payouts) {
    persona.history.filter((t) => payouts.txnIds.includes(t.id)).forEach((t) => {
      const k = apKey(t.date)
      histEarnings.set(k, (histEarnings.get(k) ?? 0) + t.amount)
    })
  }
  const ucSums = new Map<string, { date: Date; sum: number }>()

  const dates = Array.from({ length: H }, (_, i) => addDays(TODAY, i))

  for (let p = 0; p < N; p++) {
    let bal = persona.startBalance + (o.startBoost ?? 0)
    let neg = false
    const earn = new Map(histEarnings)
    const xmasTotal = Math.min(persona.priors.christmasSpend * Math.exp(0.35 * normal(rng) - 0.06), 600)
    const xmas = has('christmas_cap') ? Math.min(xmasTotal, 150) : xmasTotal
    const xmasWeights = Array.from({ length: 24 }, (_, k) => 1 + k / 8)
    const xmasW = xmasWeights.reduce((a, b) => a + b, 0)

    for (let i = 0; i < H; i++) {
      const d = dates[i]
      const dom = d.getDate()
      const dow = d.getDay()
      const mon = d.getMonth()
      let flow = 0

      for (const r of L.recurring) {
        const isCT = r.mcc === '9311'
        let slot = r.slot
        if (isCT && has('ctax_date') && d >= new Date(2026, 11, 1)) slot = 22
        const hit = r.period === 'weekly' ? dow === slot : dom === slot
        if (!hit) continue
        if (r.isUC) continue // modelled mechanically below
        let amt = r.amounts[Math.floor(rng() * r.amounts.length)]
        if (isCT) {
          if (COUNCIL_TAX_FREE_MONTHS.includes(mon)) continue
          if (has('single_person_discount') && d >= new Date(2026, 11, 1)) amt *= 0.75
        }
        if (r.mcc === '4899' && has('social_tariff') && d >= new Date(2026, 11, 15)) amt = -15
        if (/Prime/.test(r.merchant) && has('prime_unused')) amt = 0
        for (const ov of o.overrides ?? []) if (ov.match(r) && d >= ov.from) amt = ov.amount
        if (r.mcc === '6513' && o.shocks?.rentRise && d >= new Date(2027, 0, 1)) amt *= 1 + o.shocks.rentRise
        if (r.mcc === '4900' && r.period === 'weekly' && (mon === 11 || mon <= 1)) amt *= persona.priors.winterEnergyUplift
        if (r.isIncome && r.period === 'weekly') {
          // platform payouts: busier in the run-up to Christmas, dead on the day itself
          const busy = (mon === 10 && dom >= 15) || (mon === 11 && dom <= 23)
          amt *= busy ? persona.priors.busySeasonEarnings : 1
          if (mon === 11 && dom >= 24 && dom <= 27) amt *= 0.4
          amt = Math.max(60, amt * (1 + 0.04 * normal(rng)))
          if (uc) { const k = apKey(d); earn.set(k, (earn.get(k) ?? 0) + amt) }
        }
        flow += amt
      }

      // Universal Credit: 55p withdrawn per £1 earned in the assessment period that just ended
      if (uc && dom === uc.payDay) {
        const e = earn.get(apKey(addDays(d, -8))) ?? 0
        const amt = Math.max(0, uc.maxAward - 0.55 * Math.max(0, e - uc.workAllowance))
        flow += amt
        const k = d.toDateString()
        const s = ucSums.get(k) ?? { date: d, sum: 0 }
        s.sum += amt
        ucSums.set(k, s)
      }

      // Everyday spending: replay a real day from history with the same weekday
      const bucket = o.shocks?.noIrregularIncome ? L.everydayOut[dow] : L.everyday[dow]
      flow += bucket[Math.floor(rng() * bucket.length)]
      for (const s of o.shocks?.oneOffs ?? []) if (s.date.toDateString() === d.toDateString()) flow += s.amount

      // Seasonal prior: Christmas
      if (mon === 11 && dom <= 24) flow -= (xmas * xmasWeights[dom - 1]) / xmasW
      if (has('clubcard_xmas') && mon === 11 && dom === 12) flow += 18.4

      // Saving / investing transfer the day after the main income lands
      if (o.monthlySaving > 0) {
        const transferDay = uc ? uc.payDay + 1 : 28
        const startsJan = persona.onUC
        if (dom === transferDay && (!startsJan || d >= new Date(2027, 0, 1))) flow -= o.monthlySaving
      }

      bal += flow
      balances[i][p] = bal
      if (bal < 0) neg = true
    }
    if (neg) anyNeg++
  }

  const q = (s: Float64Array, f: number) => s[Math.min(s.length - 1, Math.floor(f * s.length))]
  const days: DayStat[] = balances.map((arr, i) => {
    const s = Float64Array.from(arr).sort()
    let negs = 0
    for (let k = 0; k < arr.length; k++) if (arr[k] < 0) negs++
    const pNeg = negs / arr.length
    return { i, date: dates[i], p10: q(s, 0.1), p25: q(s, 0.25), p50: q(s, 0.5), p75: q(s, 0.75), p90: q(s, 0.9), pNeg, level: levelOf(pNeg) }
  })
  const worstDay = days.reduce((w, d) => (d.pNeg > w.pNeg ? d : w), days[0])
  return {
    days,
    pAnyNeg: anyNeg / N,
    ucByMonth: [...ucSums.values()].map((s) => ({ date: s.date, mean: s.sum / N })),
    worstDay,
  }
}

/** Largest monthly saving that keeps the chance of ever going overdrawn under `limit`. */
export function safeToSave(persona: Persona, L: Learned, moves: Set<string>, limit = 0.1, extra: Partial<SimOptions> = {}) {
  let lo = 0
  let hi = 600
  if (simulate(persona, L, { ...extra, moves, monthlySaving: 0, paths: 250 }).pAnyNeg > limit) return 0
  while (hi - lo > 5) {
    const mid = Math.round((lo + hi) / 2 / 5) * 5
    const f = simulate(persona, L, { ...extra, moves, monthlySaving: mid, paths: 250 })
    if (f.pAnyNeg <= limit) lo = mid
    else hi = mid
  }
  return lo
}

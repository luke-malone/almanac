// Synthetic 90-day bank history for the demo persona.
// Generated deterministically, emitted in Open Banking shape and parsed back —
// the engines only ever see the transactions, never these rules.
import { addDays, iso, TODAY } from '../lib/dates'
import { between, mulberry32, normal, pick, type Rng } from '../lib/rng'
import type { OBTransaction, Persona, Txn } from './types'

type Emit = (date: Date, amount: number, merchant: string, info?: string, mcc?: string) => void

function build(seed: number, days: number, gen: (d: Date, rng: Rng, emit: Emit) => void) {
  const rng = mulberry32(seed)
  const raw: OBTransaction[] = []
  let n = 0
  const emit: Emit = (date, amount, merchant, info = merchant.toUpperCase(), mcc) => {
    n++
    raw.push({
      AccountId: 'demo-current-001',
      TransactionId: `tx-${seed}-${n}`,
      BookingDateTime: `${iso(date)}T${String(8 + (n % 12)).padStart(2, '0')}:00:00+00:00`,
      Amount: { Amount: Math.abs(amount).toFixed(2), Currency: 'GBP' },
      CreditDebitIndicator: amount >= 0 ? 'Credit' : 'Debit',
      Status: 'Booked',
      TransactionInformation: info,
      MerchantDetails: { MerchantName: merchant, MerchantCategoryCode: mcc },
    })
  }
  for (let i = days; i >= 1; i--) gen(addDays(TODAY, -i), rng, emit)
  return raw
}

export function parse(raw: OBTransaction[]): Txn[] {
  return raw.map((t) => ({
    id: t.TransactionId,
    date: new Date(t.BookingDateTime.slice(0, 10) + 'T12:00:00'),
    amount: (t.CreditDebitIndicator === 'Credit' ? 1 : -1) * parseFloat(t.Amount.Amount),
    merchant: t.MerchantDetails?.MerchantName ?? t.TransactionInformation,
    info: t.TransactionInformation,
    mcc: t.MerchantDetails?.MerchantCategoryCode,
  }))
}

const r2 = (n: number) => Math.round(n * 100) / 100

// Sam: healthcare assistant in Manchester. Salary on the 27th, irregular bank shifts,
// renting with a flatmate, two credit cards, wants to buy a first home one day.
function samDay(d: Date, rng: Rng, emit: Emit) {
  const dom = d.getDate()
  const dow = d.getDay()
  if (dom === 27) emit(d, 1830, 'NHS Trust Payroll', 'SALARY MANCHESTER UNIV NHS FT', '9399')
  if (dow === 5 && rng() < 0.45) emit(d, r2(between(rng, 92, 168)), 'NHSP Bank Shifts', 'NHS PROFESSIONALS BANK', '9399')
  if (dom === 1) emit(d, -650, 'Parkside Lettings', 'RENT PARKSIDE LETTINGS', '6513')
  if (dom === 1) emit(d, -96, 'Manchester City Council', 'COUNCIL TAX DD', '9311')
  if (dom === 8) emit(d, -78, 'Octopus Energy', 'OCTOPUS ENERGY DD', '4900')
  if (dom === 12) emit(d, -34, 'BT Broadband', 'BT GROUP PLC DD', '4899')
  if (dom === 14) emit(d, -24, 'EE', 'EE LIMITED DD', '4814')
  if (dom === 18) emit(d, -27.99, 'PureGym', 'PUREGYM DD', '7997')
  if (dom === 2) emit(d, -10.99, 'Netflix', 'NETFLIX.COM', '5815')
  if (dom === 22) emit(d, -8.99, 'Disney+', 'DISNEY PLUS', '5815')
  if (dom === 6) emit(d, -11.99, 'Spotify', 'SPOTIFY P1', '5815')
  // Card statements, paid in full by direct debit
  if (dom === 5) emit(d, -r2(between(rng, 360, 470)), 'Everyday Cashback Card', 'CARD PAYMENT EVERYDAY CASHBACK', '6012')
  // Debit-card spending
  if ([1, 2, 3, 4].includes(dow) && rng() < 0.8) emit(d, -9.4, 'Northern Rail', 'NORTHERN TRAINS', '4112')
  if (dow === 6) emit(d, -r2(between(rng, 38, 64)), "Sainsbury's", 'SAINSBURYS S/MKTS', '5411')
  if (dow === 3 && rng() < 0.7) {
    const saved = rng() < 0.5 ? r2(between(rng, 0.9, 2.4)) : 0
    emit(d, -r2(between(rng, 12, 26)), 'Tesco', saved ? `TESCO EXPRESS CLUBCARD PRICES SAVED ${saved.toFixed(2)}` : 'TESCO EXPRESS', '5411')
  }
  if (rng() < 0.28) emit(d, -r2(between(rng, 4.5, 14)), pick(rng, ['Pret A Manger', 'Greggs', 'Costa Coffee']), undefined, '5814')
  if (dow === 5 && rng() < 0.5) emit(d, -r2(between(rng, 18, 32)), 'Deliveroo', 'DELIVEROO', '5812')
  if (rng() < 0.06) emit(d, -r2(between(rng, 15, 55) * (1 + 0.1 * normal(rng))), pick(rng, ['Boots', 'Primark', 'Amazon']), undefined, '5311')
}

const raw = build(23, 90, samDay)

export const SAM: Persona = {
  id: 'sam',
  name: 'Sam',
  age: 26,
  role: 'Healthcare assistant',
  city: 'Manchester',
  blurb: 'NHS salary plus irregular bank shifts. Renting, two credit cards, wants a first home one day.',
  startBalance: 640,
  essentials: 1150,
  accounts: { current: 640, easyAccess: 1200, lisa: 0, investments: 0 },
  savingForFirstHome: true,
  nhsWorker: true,
  onUC: false,
  livesAlone: false,
  priors: { christmasSpend: 260, winterEnergyUplift: 1, busySeasonEarnings: 1 },
  // loyalty schemes not tied to a card (card points live on the card)
  points: [
    { scheme: 'Tesco Clubcard', balance: 1240 },
    { scheme: 'Nectar', balance: 3100 },
  ],
  raw,
  history: parse(raw),
}

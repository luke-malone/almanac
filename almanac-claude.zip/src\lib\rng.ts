// Seeded PRNG (mulberry32). Every simulation uses a fixed seed so the demo is
// repeatable, and toggling an action re-runs with the SAME random numbers
// (common random numbers) — the difference you see is the action, not noise.
export type Rng = () => number

export function mulberry32(seed: number): Rng {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function normal(rng: Rng): number {
  let u = 0
  while (u === 0) u = rng()
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rng())
}

export function between(rng: Rng, lo: number, hi: number) {
  return lo + (hi - lo) * rng()
}

export function pick<T>(rng: Rng, xs: T[]): T {
  return xs[Math.floor(rng() * xs.length)]
}

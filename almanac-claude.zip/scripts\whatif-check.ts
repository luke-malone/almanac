// Checks the "should I spend this?" tool against the real engine.   npm run check
import assert from 'node:assert/strict'
import { SAM } from '../src/data/personas'
import { learn } from '../src/engine/learn'
import { simulate } from '../src/engine/forecast'
import { DEFAULT_CARDS, planCards, spendByCategory } from '../src/engine/cards'
import { actionsFor } from '../src/engine/savings'
import { intentFromModel, parseSpend, parseWhen, runWhatIf, whatIfFacts, whatIfReply, type WhatIfInput } from '../src/ai/whatif'

const L = learn(SAM.history)
const spend = spendByCategory(SAM)
const actions = actionsFor(SAM, L, planCards(DEFAULT_CARDS, spend).gain)
const input = (done: string[] = []): WhatIfInput => {
  const d = new Set(done)
  const ov = actions.filter((a) => d.has(a.id)).flatMap((a) => a.overrides ?? [])
  const boost = actions.filter((a) => d.has(a.id)).reduce((s, a) => s + (a.startBoost ?? 0), 0)
  return { persona: SAM, learned: L, spend, actions, done: d, overrides: ov, startBoost: boost,
    forecast: simulate(SAM, L, { moves: new Set(), monthlySaving: 0, overrides: ov, startBoost: boost }) }
}

// reading the questions from the brief
assert.deepEqual(parseSpend('Hey, I want to spend 100 pounds out tonight. Should I do this?'), { amount: 100, category: 'dining', daysFromNow: 0 })
assert.deepEqual(parseSpend('is it worth it to spend 50 pounds on groceries'), { amount: 50, category: 'groceries', daysFromNow: 0 })
assert.equal(parseSpend('can i spend £1,200.50 on a laptop')?.amount, 1200.5)
assert.equal(parseSpend('should I spend a hundred pounds tonight')?.amount, 100)
assert.equal(parseSpend('Can I afford to invest?'), null)
assert.equal(parseSpend('can I invest £200 a month'), null)
assert.equal(parseSpend('Which card should I use for groceries?'), null)
assert.equal(parseWhen('buy it tomorrow'), 1)
assert.equal(intentFromModel({ intent: 'spend_check', amount: 99999 }, 'x'), null)
assert.equal(intentFromModel({ intent: 'general', amount: 10 }, 'x'), null)
assert.deepEqual(intentFromModel({ intent: 'spend_check', amount: 40, category: 'yachts', days_from_now: 2 }, 'spend £40 on a thing'), { amount: 40, category: 'other', daysFromNow: 2 })
assert.equal(intentFromModel({ intent: 'spend_check', amount: 40, category: 'yachts' }, 'spend £40 at the pub')?.category, 'dining', 'bad model category falls back to the regex reading')

// the maths
const s = input()
const t0 = performance.now()
const w100 = runWhatIf(s, { amount: 100, category: 'dining', daysFromNow: 0 })
const ms = performance.now() - t0
console.log(`£100 tonight: ${(w100.before.pAny * 100).toFixed(0)}% -> ${(w100.after.pAny * 100).toFixed(0)}%  verdict=${w100.verdict}  safeNow=£${w100.safeNow}  cushion=${JSON.stringify(w100.cushion && { after: +w100.cushion.after.pAny.toFixed(2), safe: w100.cushion.safe })}  (${ms.toFixed(0)} ms)`)
assert.ok(w100.after.pAny > w100.before.pAny, 'spending raises the risk')
assert.ok(w100.after.low < w100.before.low, 'spending lowers the lowest balance')
assert.equal(Math.round(w100.before.low - w100.after.low), 100, 'the lowest-balance day moves by exactly the spend')
assert.equal(w100.verdict, 'hold')
assert.ok(w100.cushion && w100.cushion.after.pAny < w100.after.pAny, 'cushion lowers the risk')
assert.ok(w100.cushion!.safe >= 100 || w100.cushion!.after.pAny > 0.1)
assert.ok(w100.cutCosts.length > 0 && w100.cutCosts.every((c) => c.yearly > 0))

let prev = -1
for (const amount of [10, 50, 100, 200, 400]) {
  const p = runWhatIf(s, { amount, category: 'other', daysFromNow: 0 }).after.pAny
  assert.ok(p >= prev, 'risk never falls as the spend grows'); prev = p
}

const tiny = runWhatIf(input(['cushion']), { amount: 20, category: 'other', daysFromNow: 0 })
console.log(`£20 after cushion: verdict=${tiny.verdict} ${(tiny.before.pAny * 100).toFixed(0)}% -> ${(tiny.after.pAny * 100).toFixed(0)}%`)
assert.ok(tiny.cushion === undefined, 'cushion already done is not suggested again')

const food = runWhatIf(s, { amount: 50, category: 'groceries', daysFromNow: 0 })
assert.equal(food.verdict, 'essential')
assert.ok(food.usual && food.usual.monthly > 0)
assert.ok(food.cutCosts.some((c) => ['clubcard', 'nectar', 'card_routing'].includes(c.id)), 'groceries gets grocery savings first')

// what the model is given, and the offline answer, share the same numbers
for (const w of [w100, food, tiny]) {
  const facts = whatIfFacts(w).join('\n')
  const r = whatIfReply(w)
  assert.ok(facts.includes(`${Math.round(w.after.pAny * 100)}%`))
  assert.ok(r.text.includes(`${Math.round(w.after.pAny * 100)}%`))
  assert.ok(!/NaN|undefined|Infinity/.test(facts + r.text), 'no broken numbers')
}
console.log('\n--- facts sent to the model (£100 tonight) ---\n' + whatIfFacts(w100).join('\n'))
console.log('\n--- built-in reply (£100 tonight) ---\n' + whatIfReply(w100).text)
console.log('\n--- built-in reply (£50 groceries) ---\n' + whatIfReply(food).text)
console.log('\nall checks passed')

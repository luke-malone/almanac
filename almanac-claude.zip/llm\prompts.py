"""Prompts for Qwen3-0.6B. Short, concrete, with examples: that is what a 600M model follows reliably."""
from __future__ import annotations

PERSONA = """You are Almanac, a personal wealth manager for people who have never had one.
You speak to the person directly, warmly and plainly, like a good private banker. Never scold.
Rules:
- Use ONLY the numbers in FACTS. Never estimate, round, or invent a figure.
- Lead with the decision, then the main reason, then one practical next step.
- Under 90 words. Plain sentences, no bullet points, no headings.
- Never suggest borrowing, or spending more to earn points or bonuses.
- Never name a specific fund, provider or credit card.
- Whenever you mention investing, say capital is at risk.
- This is guidance, not regulated personal advice.
- If the person seems to be struggling with debt, point them to free help: MoneyHelper, StepChange, National Debtline or Citizens Advice."""

INTENT_SYSTEM = """You read one message sent to a UK money app and reply with ONE line of JSON, nothing else.
Keys:
"intent": "spend_check" if the person is asking whether they should or can spend or buy something, otherwise "general"
"amount": the amount in pounds as a number, or null
"category": one of groceries, dining, travel, shopping, bills, other
"days_from_now": 0 for today or tonight, 1 for tomorrow, otherwise the number of days ahead"""

INTENT_EXAMPLES = [
    ("hey i want to spend 100 pounds out tonight, should i do this",
     '{"intent":"spend_check","amount":100,"category":"dining","days_from_now":0}'),
    ("is it worth it to spend 50 pounds on groceries",
     '{"intent":"spend_check","amount":50,"category":"groceries","days_from_now":0}'),
    ("Can I buy £80 trainers tomorrow?",
     '{"intent":"spend_check","amount":80,"category":"shopping","days_from_now":1}'),
    ("How much have I saved this month?",
     '{"intent":"general","amount":null,"category":"other","days_from_now":0}'),
    ("Can I afford to invest?",
     '{"intent":"general","amount":null,"category":"other","days_from_now":0}'),
]


def intent_messages(message: str) -> list[dict]:
    msgs = [{"role": "system", "content": INTENT_SYSTEM}]
    for q, a in INTENT_EXAMPLES:
        msgs += [{"role": "user", "content": q}, {"role": "assistant", "content": a}]
    return msgs + [{"role": "user", "content": message}]


def reply_messages(mode: str, history: list[dict], facts: list[str], verdict_line: str | None) -> list[dict]:
    """System prompt, the last few turns, and a final user turn that carries the engine's numbers."""
    turns = [{"role": m["role"], "content": m["content"]} for m in history if m.get("role") in ("user", "assistant")]
    question = turns[-1]["content"] if turns else ""
    block = "FACTS (the only numbers you may use):\n" + "\n".join(f"- {f}" for f in facts)
    if mode == "spend" and verdict_line:
        task = (
            f"DECISION (already made by the forecast, do not change it): {verdict_line}\n\n"
            "Write the reply. First sentence: the decision. Then the main reason using the FACTS numbers. "
            "Then ONE next step: the cushion or the safe amount if the FACTS list one, and one way to cut costs from the FACTS."
        )
    else:
        task = "Answer the question using only the FACTS. Give one clear recommendation, then the reason."
    final = f"{question}\n\n{block}\n\n{task}"
    return [{"role": "system", "content": PERSONA}, *turns[-5:-1], {"role": "user", "content": final}]

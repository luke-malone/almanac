"""Small adapter that lets the existing guarded chat flow use Claude."""
from __future__ import annotations

import os

from anthropic import Anthropic


class ClaudeChat:
    model_id = os.environ.get("CLAUDE_MODEL", "claude-sonnet-4-6")
    device = "Anthropic API"

    def __init__(self):
        self.client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

    def generate(self, messages: list[dict], max_new_tokens: int = 200, temperature: float = 0.0) -> str:
        system = "\n\n".join(m["content"] for m in messages if m.get("role") == "system")
        turns = [
            {"role": m["role"], "content": m["content"]}
            for m in messages
            if m.get("role") in ("user", "assistant")
        ]
        response = self.client.messages.create(
            model=self.model_id,
            max_tokens=max_new_tokens,
            system=system,
            messages=turns,
        )
        return "\n".join(block.text for block in response.content if block.type == "text")

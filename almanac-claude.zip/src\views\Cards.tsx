import { useEffect, useRef, useState } from 'react'
import { useApp } from '../state'
import { money, money2 } from '../lib/format'
import { animate, reducedMotion } from '../lib/motion'
import { CARD_TEMPLATES, CATEGORY_LABEL, POINT_VALUES, planCards, spendByCategory, type Card, type Scheme } from '../engine/cards'
import { Badge, Button, Modal, Panel, Progress } from '../ui/kit'

function CardFace({ c, onRemove }: { c: Card; onRemove?: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (ref.current && !reducedMotion()) animate(ref.current, { opacity: [0, 1], translateY: [16, 0], duration: 600, ease: 'outQuint' })
  }, [])
  const v = POINT_VALUES[c.scheme]
  return (
    <div ref={ref} className="relative flex aspect-[1.586] w-[300px] shrink-0 flex-col justify-between rounded-2xl p-5 text-white shadow-[0_12px_30px_-12px_rgba(16,24,40,.45)]" style={{ background: c.tone }}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[15px] font-semibold">{c.name}</p>
          <p className="text-[12px] text-white/70">{c.scheme === 'Cashback' ? `${c.earn.base}% cashback` : c.scheme === 'None' ? 'No rewards' : `${c.scheme}, ${c.earn.base} per £1`}</p>
        </div>
        <p className="text-[13px] font-semibold tracking-wide text-white/90">{c.network}</p>
      </div>
      <div>
        <p className="tnum text-[15px] tracking-[0.18em] text-white/85">•••• {c.last4}</p>
        <div className="mt-2 flex items-end justify-between">
          <div>
            <p className="text-[11px] text-white/60">{c.scheme === 'Cashback' ? 'Cashback earned' : 'Points'}</p>
            <p className="tnum text-[17px] font-semibold">{c.scheme === 'Cashback' ? money2(c.pointsBalance / 100) : c.pointsBalance.toLocaleString()}</p>
          </div>
          <div className="text-right">
            <p className="text-[11px] text-white/60">Balance owed</p>
            <p className="tnum text-[17px] font-semibold">{money2(c.balance)}</p>
          </div>
        </div>
        {c.scheme !== 'Cashback' && c.scheme !== 'None' && (
          <p className="mt-1 text-[11.5px] text-white/70">Worth {money2((c.pointsBalance * v.cash) / 100)} to {money2((c.pointsBalance * v.best) / 100)}</p>
        )}
      </div>
      {onRemove && <button onClick={onRemove} className="absolute -top-2 -right-2 rounded-full border border-line bg-surface px-2 py-0.5 text-[11px] font-medium text-sub shadow">Remove</button>}
    </div>
  )
}

export function Cards() {
  const { cards, plan, progs, trip, setAddOpen, removeCard, done, toggle, complete } = useApp()
  const routed = done.has('card_routing')
  return (
    <div className="space-y-5">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-[26px] font-semibold tracking-tight">Cards and points</h1>
          <p className="mt-1 text-[14px] text-sub">What each card should be used for, what your points are worth, and when to spend them.</p>
        </div>
        <Button onClick={() => setAddOpen(true)}>Add a card</Button>
      </header>

      {plan.warnings.map((w) => (
        <div key={w.card.id} className="rounded-2xl border border-[#f4c7c2] bg-risk-soft px-5 py-4 text-[14px] text-[#7a271a]">
          <span className="font-semibold">Pay off {w.card.name} before anything else.</span> You owe {money2(w.card.balance)} at {w.card.apr}% APR. That costs about {money(w.interestYearly)} a year in interest, more than every reward on this page put together. I’ve left it out of the rewards plan until it’s cleared.
        </div>
      ))}

      <div className="no-scrollbar -mx-1 flex gap-5 overflow-x-auto px-1 pt-2 pb-3">
        {cards.map((c) => <CardFace key={c.id} c={c} onRemove={c.id.startsWith('u') ? () => removeCard(c.id) : undefined} />)}
        <button onClick={() => setAddOpen(true)} className="flex aspect-[1.586] w-[300px] shrink-0 flex-col items-center justify-center rounded-2xl border-2 border-dashed border-line text-[14px] font-medium text-sub hover:border-[#c7ccd4] hover:text-ink">
          Add a card
          <span className="mt-1 text-[12.5px] font-normal text-mute">Name, rewards and points balance</span>
        </button>
      </div>

      <Panel title="Best card for each kind of spending"
          aside={<span>About <span className="tnum font-semibold text-ink">{money(plan.optimisedYearly)}</span> a year, vs <span className="tnum">{money(plan.currentYearly)}</span> now</span>}>
          <table className="w-full text-[13.5px]">
            <thead>
              <tr className="border-b border-line text-left text-[12.5px] text-mute">
                <th className="pb-2 font-medium">Spending</th>
                <th className="pb-2 text-right font-medium">Per month</th>
                <th className="pb-2 pl-6 font-medium">Use</th>
                <th className="pb-2 text-right font-medium">Back per £1</th>
                <th className="pb-2 text-right font-medium">Per year</th>
              </tr>
            </thead>
            <tbody>
              {plan.rows.map((r) => (
                <tr key={r.cat} className="border-b border-line-2 last:border-0">
                  <td className="py-2.5">{CATEGORY_LABEL[r.cat]}</td>
                  <td className="tnum py-2.5 text-right">{money(r.monthly)}</td>
                  <td className="py-2.5 pl-6 font-medium">{r.best?.name ?? 'Any card paid in full'}</td>
                  <td className="tnum py-2.5 text-right">{(r.rate * 100).toFixed(1)}p</td>
                  <td className="tnum py-2.5 text-right font-medium text-gain">{money(r.yearly)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-4 flex items-center justify-between gap-4 rounded-xl bg-bg px-4 py-3">
            <p className="text-[13px] text-sub">Only worth it because you pay every card in full. Set each card as the default in your phone wallet for its category.</p>
            <Button size="sm" variant={routed ? 'done' : 'primary'} onClick={() => (routed ? toggle('card_routing') : complete('card_routing'))}>
              {routed ? 'Done' : `Do this: +${money(plan.gain)}/yr`}
            </Button>
          </div>
      </Panel>

      <div className="grid grid-cols-2 gap-5">
          {plan.bonuses.map((b) => (
            <Panel key={b.card.id} title="Welcome bonus" aside={<Badge tone={b.onTrack ? 'gain' : 'risk'}>{b.onTrack ? 'Reachable with normal spending' : 'Not worth chasing'}</Badge>}>
              <p className="text-[13.5px] text-sub">{b.card.name}: <span className="font-semibold text-ink">{b.card.bonus!.points.toLocaleString()} points</span> (about {money(b.valuePounds)}) for spending {money(b.card.bonus!.spendRequired)} in the next {b.card.bonus!.daysLeft} days.</p>
              <div className="mt-3"><Progress value={b.card.bonus!.spentSoFar / b.card.bonus!.spendRequired} /></div>
              <div className="mt-1.5 flex justify-between text-[12.5px] text-mute">
                <span className="tnum">{money(b.card.bonus!.spentSoFar)} spent</span>
                <span className="tnum">On course for {money(Math.min(b.projected, 9999))} by the deadline</span>
              </div>
              <p className="mt-3 text-[12.5px] text-mute">I only show a bonus if your usual spending reaches it. Never spend extra to get one.</p>
            </Panel>
          ))}
          <Panel title="A trip your points could cover" aside={<Badge>Illustrative prices</Badge>}>
            <p className="text-[13.5px] leading-relaxed text-sub">{trip.text}</p>
            <div className="mt-3 flex items-baseline justify-between text-[13px]">
              <span className="text-mute">Avios you’ll have by February</span>
              <span className="tnum font-semibold">{trip.byFeb.toLocaleString()} <span className="font-normal text-mute">({trip.byFeb >= trip.need ? 'enough' : `${(trip.need - trip.byFeb).toLocaleString()} short`})</span></span>
            </div>
            <div className="mt-1.5"><Progress value={trip.byFeb / trip.need} tone="#067A55" /></div>
          </Panel>
      </div>

      <Panel title="What your points are worth" aside={<span>Values are typical estimates, in pence per point</span>}>
        <table className="w-full text-[13.5px]">
          <thead>
            <tr className="border-b border-line text-left text-[12.5px] text-mute">
              <th className="pb-2 font-medium">Programme</th>
              <th className="pb-2 text-right font-medium">Balance</th>
              <th className="pb-2 pl-6 font-medium">Easiest use</th>
              <th className="pb-2 text-right font-medium">Worth</th>
              <th className="pb-2 pl-6 font-medium">Best use</th>
              <th className="pb-2 text-right font-medium">Worth</th>
            </tr>
          </thead>
          <tbody>
            {progs.map((p) => (
              <tr key={p.scheme} className="border-b border-line-2 last:border-0">
                <td className="py-2.5 font-medium">{p.scheme}<span className="block text-[12px] font-normal text-mute">{p.from.join(', ')}</span></td>
                <td className="tnum py-2.5 text-right">{p.scheme === 'Cashback' ? money2(p.balance / 100) : p.balance.toLocaleString()}</td>
                <td className="py-2.5 pl-6 text-sub">{p.cashUse}</td>
                <td className="tnum py-2.5 text-right">{money2(p.cash)}</td>
                <td className="py-2.5 pl-6 text-sub">{p.bestUse}</td>
                <td className="tnum py-2.5 text-right font-semibold text-brand">{money2(p.best)}</td>
              </tr>
            ))}
            <tr>
              <td className="pt-3 font-semibold">Total</td><td /><td />
              <td className="tnum pt-3 text-right font-semibold">{money2(progs.reduce((a, p) => a + p.cash, 0))}</td><td />
              <td className="tnum pt-3 text-right font-semibold text-brand">{money2(progs.reduce((a, p) => a + p.best, 0))}</td>
            </tr>
          </tbody>
        </table>
      </Panel>
      <AddCard />
    </div>
  )
}

const SCHEMES: Scheme[] = ['Cashback', 'Avios', 'Membership Rewards', 'Tesco Clubcard', 'Nectar', 'None']
const TONES = ['linear-gradient(135deg,#0f766e,#134e4a)', 'linear-gradient(135deg,#9a3412,#7c2d12)', 'linear-gradient(135deg,#7c3aed,#4c1d95)', 'linear-gradient(135deg,#475569,#1e293b)']

function AddCard() {
  const { addOpen, setAddOpen, addCard, cards, persona, flash, say } = useApp()
  const blank = { template: '', name: '', network: 'Visa' as Card['network'], scheme: 'Avios' as Scheme, base: '1', travel: '', groceries: '', dining: '', points: '', balance: '0', apr: '24.9', fee: '0', paysInFull: true }
  const [f, setF] = useState(blank)
  const set = (k: keyof typeof f, v: string | boolean) => setF((x) => ({ ...x, [k]: v }))

  const applyTemplate = (i: string) => {
    const t = CARD_TEMPLATES[+i]
    if (!t) { setF(blank); return }
    setF({ ...f, template: i, name: t.name, network: t.network, scheme: t.scheme, base: String(t.earn.base), travel: String(t.earn.travel ?? ''), groceries: String(t.earn.groceries ?? ''), dining: String(t.earn.dining ?? ''), apr: String(t.apr), fee: String(t.annualFee), points: t.scheme === 'Membership Rewards' ? '12000' : t.scheme === 'Tesco Clubcard' ? '850' : '' })
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const num = (s: string) => (s.trim() === '' ? undefined : Math.max(0, parseFloat(s) || 0))
    const c: Card = {
      id: `u${Date.now()}`,
      name: f.name.trim() || 'My card',
      network: f.network,
      last4: String(1000 + Math.floor(Math.random() * 9000)),
      scheme: f.scheme,
      earn: { base: num(f.base) ?? 0, travel: num(f.travel), groceries: num(f.groceries), dining: num(f.dining) },
      annualFee: num(f.fee) ?? 0,
      balance: num(f.balance) ?? 0,
      apr: num(f.apr) ?? 0,
      paysInFull: f.paysInFull,
      pointsBalance: f.scheme === 'Cashback' ? (num(f.points) ?? 0) * 100 : num(f.points) ?? 0,
      tone: CARD_TEMPLATES[+f.template]?.tone ?? TONES[cards.length % TONES.length],
      currentShare: 0,
    }
    addCard(c)
    setAddOpen(false)
    setF(blank)
    const v = POINT_VALUES[c.scheme]
    const after = planCards([...cards, c], spendByCategory(persona))
    const wins = after.rows.filter((r) => r.best?.id === c.id).map((r) => CATEGORY_LABEL[r.cat].toLowerCase())
    flash(`${c.name} added`)
    say(
      !c.paysInFull && c.balance > 0
        ? `I’ve added ${c.name}. You’re carrying ${money2(c.balance)} on it at ${c.apr}% APR, which costs about ${money(c.balance * c.apr / 100)} a year. Clear that before thinking about rewards. I’ve left it out of your card plan for now.`
        : `I’ve added ${c.name}.${c.pointsBalance > 0 && c.scheme !== 'Cashback' && c.scheme !== 'None' ? ` Its ${c.pointsBalance.toLocaleString()} ${c.scheme} points are worth ${money2(c.pointsBalance * v.cash / 100)} as money off, or up to ${money2(c.pointsBalance * v.best / 100)} used well (${v.bestUse.charAt(0).toLowerCase() + v.bestUse.slice(1)}).` : ''} ${wins.length ? `It’s now your best card for ${wins.join(', ')}. Your card rewards go from ${money(planCards(cards, spendByCategory(persona)).optimisedYearly)} to ${money(after.optimisedYearly)} a year.` : 'It doesn’t beat your existing cards for any of your spending, so I’d keep it as a backup.'}${c.annualFee > 0 ? ` Remember the ${money(c.annualFee)} annual fee.` : ''}`,
    )
  }

  const field = 'mt-1 h-10 w-full rounded-lg border border-line bg-surface px-3 text-[14px] outline-none focus:border-brand'
  const label = 'block text-[12.5px] font-medium text-sub'
  return (
    <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Add a card">
      <form onSubmit={submit} className="space-y-4">
        <label className={label}>Start from an example card
          <select className={field} value={f.template} onChange={(e) => applyTemplate(e.target.value)}>
            <option value="">Enter my own details</option>
            {CARD_TEMPLATES.map((t, i) => <option key={t.name} value={i}>{t.name} ({t.scheme})</option>)}
          </select>
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className={label}>Card name<input className={field} value={f.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Aurora Rewards" required /></label>
          <label className={label}>Network
            <select className={field} value={f.network} onChange={(e) => set('network', e.target.value)}>
              {['Visa', 'Mastercard', 'Amex'].map((n) => <option key={n}>{n}</option>)}
            </select>
          </label>
          <label className={label}>Rewards
            <select className={field} value={f.scheme} onChange={(e) => set('scheme', e.target.value)}>
              {SCHEMES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>
          <label className={label}>{f.scheme === 'Cashback' ? 'Cashback % on everything' : 'Points per £1 on everything'}<input className={field} inputMode="decimal" value={f.base} onChange={(e) => set('base', e.target.value)} /></label>
        </div>
        {f.scheme !== 'None' && (
          <div>
            <p className={label}>Higher rate on these (optional)</p>
            <div className="mt-1 grid grid-cols-3 gap-3">
              <label className="text-[12px] text-mute">Travel<input className={field} inputMode="decimal" placeholder="Same" value={f.travel} onChange={(e) => set('travel', e.target.value)} /></label>
              <label className="text-[12px] text-mute">Groceries<input className={field} inputMode="decimal" placeholder="Same" value={f.groceries} onChange={(e) => set('groceries', e.target.value)} /></label>
              <label className="text-[12px] text-mute">Eating out<input className={field} inputMode="decimal" placeholder="Same" value={f.dining} onChange={(e) => set('dining', e.target.value)} /></label>
            </div>
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <label className={label}>{f.scheme === 'Cashback' ? 'Cashback waiting (£)' : 'Points you have now'}<input className={field} inputMode="numeric" value={f.points} onChange={(e) => set('points', e.target.value)} placeholder="0" /></label>
          <label className={label}>Annual fee (£)<input className={field} inputMode="decimal" value={f.fee} onChange={(e) => set('fee', e.target.value)} /></label>
          <label className={label}>Balance owed (£)<input className={field} inputMode="decimal" value={f.balance} onChange={(e) => set('balance', e.target.value)} /></label>
          <label className={label}>Interest rate (APR %)<input className={field} inputMode="decimal" value={f.apr} onChange={(e) => set('apr', e.target.value)} /></label>
        </div>
        <label className="flex items-center gap-2.5 text-[14px]">
          <input type="checkbox" className="h-4 w-4 accent-[#4b2a86]" checked={f.paysInFull} onChange={(e) => set('paysInFull', e.target.checked)} />
          I pay this card off in full every month
        </label>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={() => setAddOpen(false)}>Cancel</Button>
          <Button type="submit">Add card</Button>
        </div>
      </form>
    </Modal>
  )
}
